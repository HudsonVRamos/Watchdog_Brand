"""Utilitários do Brand Watchdog."""
